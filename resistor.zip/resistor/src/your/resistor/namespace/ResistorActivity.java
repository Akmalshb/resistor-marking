package your.resistor.namespace;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.util.FloatMath;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;


public class ResistorActivity extends Activity {
    /** Called when the activity is first created. */
	
	View v2;
	View v4;
	View v6;
	View v8;
	View v10;
	View v12;
	View v14;
	Button b1;
	Button b2;
	Button b3;
	Button b4;
	Button b5;
	Button b6;
	Button b7;
	Button b8;
	TextView text1;
	int n=6;
	int c1=1;
	int c2=0;
	int c3=0;
	int c4=3;
	int c5=1;
	int c6=1;
	float r;
	float d=1;
	String f="10%",f1;
	int t=100;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        v2=(View) findViewById(R.id.v2);
        v4=(View) findViewById(R.id.v4);
        v6=(View) findViewById(R.id.v6);
        v8=(View) findViewById(R.id.v8);
        v10=(View) findViewById(R.id.v10);
        v12=(View) findViewById(R.id.v12);
        v14=(View) findViewById(R.id.v14);
        b1=(Button) findViewById(R.id.b1);
        b2=(Button) findViewById(R.id.b2);
        b3=(Button) findViewById(R.id.b3);
        b4=(Button) findViewById(R.id.b4);
        b5=(Button) findViewById(R.id.b5);
        b6=(Button) findViewById(R.id.b6);
        b7=(Button) findViewById(R.id.b7);
        b8=(Button) findViewById(R.id.b8);
        text1=(TextView) findViewById(R.id.text1);
        
        OnClickListener cb1 = new OnClickListener() {
        	//@Override	
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
			
			if(n>3){
				n=n-1;
			}
			if(n==3){
				n=3;
			}	
			switch(n){
			case 3:
				
				b6.setBackgroundColor(Color.rgb(245, 222, 179));
				b6.invalidate();
				b6.setEnabled(false);
				
				break;
			case 4:
				
				b4.setBackgroundColor(Color.rgb(245, 222, 179));
				b4.invalidate();
				b4.setEnabled(false);
				break;
				case 5:
					b7.setBackgroundColor(Color.rgb(245, 222, 179));
					b7.invalidate();
					b7.setEnabled(false);
					break;
					
			}
			}
		}; 
       	 	
			             
			b1.setOnClickListener(cb1);
        
			OnClickListener cb8 = new OnClickListener() {
	        	//@Override	
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
				
				if(n<6){
					n=n+1;
				}
				if(n==6){
					n=6;
				}	
				switch(n){
				case 4:
					
					b6.setBackgroundColor(Color.rgb(192, 192, 192));
					b6.invalidate();
					b6.setEnabled(true);
					
					break;
				case 5:
					
					b4.setBackgroundColor(Color.rgb(0,0, 0));
					b4.invalidate();
					b4.setEnabled(true);
					break;
					case 6:
						b7.setBackgroundColor(Color.rgb(165, 42, 42));
						b7.invalidate();
						b7.setEnabled(true);
						break;
						
				}
				}
			}; 
	       	 	
				             
				b8.setOnClickListener(cb8);
				
			OnClickListener cb2 = new OnClickListener() {
	        	//@Override	
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
					if(c1<10){
						c1=c1+1;
					}
					if(c1>9){
						c1=1;
					}	
					switch(c1){
					case 1:
						b2.setBackgroundColor(Color.rgb(165, 42, 42));
						b2.invalidate();
					break;
					case 2:
						b2.setBackgroundColor(Color.rgb(255, 0, 0));
						b2.invalidate();
					break;
					case 3:
						b2.setBackgroundColor(Color.rgb(255, 165, 0));
						b2.invalidate();
					break;
					case 4:
						b2.setBackgroundColor(Color.rgb(255, 255, 0));
						b2.invalidate();
					break;
					case 5:
						b2.setBackgroundColor(Color.rgb(0, 255, 0));
						b2.invalidate();
					break;
					case 6:
						b2.setBackgroundColor(Color.rgb(0, 0, 255));
						b2.invalidate();
					break;
					case 7:
						b2.setBackgroundColor(Color.rgb(238, 130, 238));
						b2.invalidate();
					break;
					case 8:
						b2.setBackgroundColor(Color.rgb(128, 128, 128));
						b2.invalidate();
					break;
					case 9:
						b2.setBackgroundColor(Color.rgb(255, 255, 255));
						b2.invalidate();
					break;
							
					}			
					 switch(n){
					 case 3:
						 r=(c1*10)+c2;
						 r=r*d;
						 if (r<1000){
							 text1.setText("R="+r+" Om");
						 }
						 if ((r>999)&(r<1000000)){
							 r=r/1000;
							 text1.setText("R="+r+" kOm");
						 }
						 if ((r>999999)&(r<1000000000)){
							 r=r/1000000;
							 text1.setText("R="+r+" MOm");
						 }
						 if (r>999999999){
							 r=r/1000000000;
							 text1.setText("R="+r+" GOm");
						 }
						 break;
					 case 4:
						 r=(c1*10)+c2;
						 r=r*d;
						 if (r<1000){
							 text1.setText("R="+r+" Om "+f);
						 }
						 if ((r>999)&(r<1000000)){
							 r=r/1000;
							 text1.setText("R="+r+" kOm "+f);
						 }
						 if ((r>999999)&(r<1000000000)){
							 r=r/1000000;
							 text1.setText("R="+r+" MOm "+f);
						 }
						 if (r>999999999){
							 r=r/1000000000;
							 text1.setText("R="+r+" GOm "+f);
						 }
						 break;
					 case 5:
						 r=(c1*100)+(c2*10)+c3;
						 r=r*d;
						 if (r<1000){
							 text1.setText("R="+r+" Om "+f);
						 }
						 if ((r>999)&(r<1000000)){
							 r=r/1000;
							 text1.setText("R="+r+" kOm "+f);
						 }
						 if ((r>999999)&(r<1000000000)){
							 r=r/1000000;
							 text1.setText("R="+r+" MOm "+f);
						 }
						 if (r>999999999){
							 r=r/1000000000;
							 text1.setText("R="+r+" GOm "+f);
						 }
						 break;
					 case 6:
						 r=(c1*100)+(c2*10)+c3;
						 r=r*d;
						 if (r<1000){
							 text1.setText("R="+r+" Om "+f+"; "+t+" ppm/C");
						 }
						 if ((r>999)&(r<1000000)){
							 r=r/1000;
							 text1.setText("R="+r+" kOm "+f+"; "+t+" ppm/C");
						 }
						 if ((r>999999)&(r<1000000000)){
							 r=r/1000000;
							 text1.setText("R="+r+" MOm "+f+"; "+t+" ppm/C");
						 }
						 if (r>999999999){
							 r=r/1000000000;
							 text1.setText("R="+r+" GOm "+f+"; "+t+" ppm/C");
						 }
						 break;
					 
					 }
					
					
				}
			}; 
	       	 	
				b2.setOnClickListener(cb2);
				
				OnClickListener cb3 = new OnClickListener() {
		        	//@Override	
					public void onClick(View arg0) {
						// TODO Auto-generated method stub
						if(c2<10){
							c2=c2+1;
						}
						if(c2>9){
							c2=0;
						}	
						switch(c2){
						case 0:
							b3.setBackgroundColor(Color.rgb(0, 0, 0));
							b3.invalidate();
						break;
						case 1:
							b3.setBackgroundColor(Color.rgb(165, 42, 42));
							b3.invalidate();
						break;
						case 2:
							b3.setBackgroundColor(Color.rgb(255, 0, 0));
							b3.invalidate();
						break;
						case 3:
							b3.setBackgroundColor(Color.rgb(255, 165, 0));
							b3.invalidate();
						break;
						case 4:
							b3.setBackgroundColor(Color.rgb(255, 255, 0));
							b3.invalidate();
						break;
						case 5:
							b3.setBackgroundColor(Color.rgb(0, 255, 0));
							b3.invalidate();
						break;
						case 6:
							b3.setBackgroundColor(Color.rgb(0, 0, 255));
							b3.invalidate();
						break;
						case 7:
							b3.setBackgroundColor(Color.rgb(238, 130, 238));
							b3.invalidate();
						break;
						case 8:
							b3.setBackgroundColor(Color.rgb(128, 128, 128));
							b3.invalidate();
						break;
						case 9:
							b3.setBackgroundColor(Color.rgb(255, 255, 255));
							b3.invalidate();
						break;
								
						}			
						switch(n){
						 case 3:
							 r=(c1*10)+c2;
							 r=r*d;
							 if (r<1000){
								 text1.setText("R="+r+" Om");
							 }
							 if ((r>999)&(r<1000000)){
								 r=r/1000;
								 text1.setText("R="+r+" kOm");
							 }
							 if ((r>999999)&(r<1000000000)){
								 r=r/1000000;
								 text1.setText("R="+r+" MOm");
							 }
							 if (r>999999999){
								 r=r/1000000000;
								 text1.setText("R="+r+" GOm");
							 }
							 break;
						 case 4:
							 r=(c1*10)+c2;
							 r=r*d;
							 if (r<1000){
								 text1.setText("R="+r+" Om "+f);
							 }
							 if ((r>999)&(r<1000000)){
								 r=r/1000;
								 text1.setText("R="+r+" kOm "+f);
							 }
							 if ((r>999999)&(r<1000000000)){
								 r=r/1000000;
								 text1.setText("R="+r+" MOm "+f);
							 }
							 if (r>999999999){
								 r=r/1000000000;
								 text1.setText("R="+r+" GOm "+f);
							 }
							 break;
						 case 5:
							 r=(c1*100)+(c2*10)+c3;
							 r=r*d;
							 if (r<1000){
								 text1.setText("R="+r+" Om "+f);
							 }
							 if ((r>999)&(r<1000000)){
								 r=r/1000;
								 text1.setText("R="+r+" kOm "+f);
							 }
							 if ((r>999999)&(r<1000000000)){
								 r=r/1000000;
								 text1.setText("R="+r+" MOm "+f);
							 }
							 if (r>999999999){
								 r=r/1000000000;
								 text1.setText("R="+r+" GOm "+f);
							 }
							 break;
						 case 6:
							 r=(c1*100)+(c2*10)+c3;
							 r=r*d;
							 if (r<1000){
								 text1.setText("R="+r+" Om "+f+"; "+t+" ppm/C");
							 }
							 if ((r>999)&(r<1000000)){
								 r=r/1000;
								 text1.setText("R="+r+" kOm "+f+"; "+t+" ppm/C");
							 }
							 if ((r>999999)&(r<1000000000)){
								 r=r/1000000;
								 text1.setText("R="+r+" MOm "+f+"; "+t+" ppm/C");
							 }
							 if (r>999999999){
								 r=r/1000000000;
								 text1.setText("R="+r+" GOm "+f+"; "+t+" ppm/C");
							 }
							 break;
						 
						 }
						
						
					}
				}; 
		       	 	
					b3.setOnClickListener(cb3);
					
					OnClickListener cb4 = new OnClickListener() {
			        	//@Override	
						public void onClick(View arg0) {
							// TODO Auto-generated method stub
							if(c3<10){
								c3=c3+1;
							}
							if(c3>9){
								c3=0;
							}	
							switch(c3){
							case 0:
								b4.setBackgroundColor(Color.rgb(0, 0, 0));
								b4.invalidate();
							break;
							case 1:
								b4.setBackgroundColor(Color.rgb(165, 42, 42));
								b4.invalidate();
							break;
							case 2:
								b4.setBackgroundColor(Color.rgb(255, 0, 0));
								b4.invalidate();
							break;
							case 3:
								b4.setBackgroundColor(Color.rgb(255, 165, 0));
								b4.invalidate();
							break;
							case 4:
								b4.setBackgroundColor(Color.rgb(255, 255, 0));
								b4.invalidate();
							break;
							case 5:
								b4.setBackgroundColor(Color.rgb(0, 255, 0));
								b4.invalidate();
							break;
							case 6:
								b4.setBackgroundColor(Color.rgb(0, 0, 255));
								b4.invalidate();
							break;
							case 7:
								b4.setBackgroundColor(Color.rgb(238, 130, 238));
								b4.invalidate();
							break;
							case 8:
								b4.setBackgroundColor(Color.rgb(128, 128, 128));
								b4.invalidate();
							break;
							case 9:
								b4.setBackgroundColor(Color.rgb(255, 255, 255));
								b4.invalidate();
							break;
									
							}			
							
							switch(n){
							 case 3:
								 r=(c1*10)+c2;
								 r=r*d;
								 if (r<1000){
									 text1.setText("R="+r+" Om");
								 }
								 if ((r>999)&(r<1000000)){
									 r=r/1000;
									 text1.setText("R="+r+" kOm");
								 }
								 if ((r>999999)&(r<1000000000)){
									 r=r/1000000;
									 text1.setText("R="+r+" MOm");
								 }
								 if (r>999999999){
									 r=r/1000000000;
									 text1.setText("R="+r+" GOm");
								 }
								 break;
							 case 4:
								 r=(c1*10)+c2;
								 r=r*d;
								 if (r<1000){
									 text1.setText("R="+r+" Om "+f);
								 }
								 if ((r>999)&(r<1000000)){
									 r=r/1000;
									 text1.setText("R="+r+" kOm "+f);
								 }
								 if ((r>999999)&(r<1000000000)){
									 r=r/1000000;
									 text1.setText("R="+r+" MOm "+f);
								 }
								 if (r>999999999){
									 r=r/1000000000;
									 text1.setText("R="+r+" GOm "+f);
								 }
								 break;
							 case 5:
								 r=(c1*100)+(c2*10)+c3;
								 r=r*d;
								 if (r<1000){
									 text1.setText("R="+r+" Om "+f);
								 }
								 if ((r>999)&(r<1000000)){
									 r=r/1000;
									 text1.setText("R="+r+" kOm "+f);
								 }
								 if ((r>999999)&(r<1000000000)){
									 r=r/1000000;
									 text1.setText("R="+r+" MOm "+f);
								 }
								 if (r>999999999){
									 r=r/1000000000;
									 text1.setText("R="+r+" GOm "+f);
								 }
								 break;
							 case 6:
								 r=(c1*100)+(c2*10)+c3;
								 r=r*d;
								 if (r<1000){
									 text1.setText("R="+r+" Om "+f+"; "+t+" ppm/C");
								 }
								 if ((r>999)&(r<1000000)){
									 r=r/1000;
									 text1.setText("R="+r+" kOm "+f+"; "+t+" ppm/C");
								 }
								 if ((r>999999)&(r<1000000000)){
									 r=r/1000000;
									 text1.setText("R="+r+" MOm "+f+"; "+t+" ppm/C");
								 }
								 if (r>999999999){
									 r=r/1000000000;
									 text1.setText("R="+r+" GOm "+f+"; "+t+" ppm/C");
								 }
								 break;
							 
							 }
							
						}
					}; 
			       	 	
						b4.setOnClickListener(cb4);
						
						OnClickListener cb5 = new OnClickListener() {
				        	//@Override	
							public void onClick(View arg0) {
								// TODO Auto-generated method stub
								if(c4<13){
									c4=c4+1;
								}
								if(c4>12){
									c4=1;
								}	
								switch(c4){
								case 1:
									b5.setBackgroundColor(Color.rgb(192, 192, 192));
									b5.invalidate();
									f1="0.01";
									//d = Float.parseFloat(f1.getText().toString());
									d = Float.valueOf(f1);
								break;
								case 2:
									b5.setBackgroundColor(Color.rgb(255, 215, 0));
									b5.invalidate();
									f1="0.1";
									//d = Float.parseFloat(f.getText().toString());
									d = Float.valueOf(f1);
								break;
								case 3:
									b5.setBackgroundColor(Color.rgb(0, 0, 0));
									b5.invalidate();
									d=1;
								break;
								case 4:
									b5.setBackgroundColor(Color.rgb(165, 42, 42));
									b5.invalidate();
									d=10;
								break;
								case 5:
									b5.setBackgroundColor(Color.rgb(255, 0, 0));
									b5.invalidate();
									d=100;
								break;
								case 6:
									b5.setBackgroundColor(Color.rgb(255, 165, 0));
									b5.invalidate();
									d=1000;
								break;
								case 7:
									b5.setBackgroundColor(Color.rgb(255, 255, 0));
									b5.invalidate();
									d=10000;
								break;
								case 8:
									b5.setBackgroundColor(Color.rgb(0, 255, 0));
									b5.invalidate();
									d=100000;
								break;
								case 9:
									b5.setBackgroundColor(Color.rgb(0, 0, 255));
									b5.invalidate();
									d=1000000;
								break;
								case 10:
									b5.setBackgroundColor(Color.rgb(238, 130, 238));
									b5.invalidate();
									d=10000000;
								break;
								case 11:
									b5.setBackgroundColor(Color.rgb(128, 128, 128));
									b5.invalidate();
									d=100000000;
								break;
								case 12:
									b5.setBackgroundColor(Color.rgb(255, 255, 255));
									b5.invalidate();
									d=1000000000;
								break;
										
								}			
								
								switch(n){
								 case 3:
									 r=(c1*10)+c2;
									 r=r*d;
									 if (r<1000){
										 text1.setText("R="+r+" Om");
									 }
									 if ((r>999)&(r<1000000)){
										 r=r/1000;
										 text1.setText("R="+r+" kOm");
									 }
									 if ((r>999999)&(r<1000000000)){
										 r=r/1000000;
										 text1.setText("R="+r+" MOm");
									 }
									 if (r>999999999){
										 r=r/1000000000;
										 text1.setText("R="+r+" GOm");
									 }
									 break;
								 case 4:
									 r=(c1*10)+c2;
									 r=r*d;
									 if (r<1000){
										 text1.setText("R="+r+" Om "+f);
									 }
									 if ((r>999)&(r<1000000)){
										 r=r/1000;
										 text1.setText("R="+r+" kOm "+f);
									 }
									 if ((r>999999)&(r<1000000000)){
										 r=r/1000000;
										 text1.setText("R="+r+" MOm "+f);
									 }
									 if (r>999999999){
										 r=r/1000000000;
										 text1.setText("R="+r+" GOm "+f);
									 }
									 break;
								 case 5:
									 r=(c1*100)+(c2*10)+c3;
									 r=r*d;
									 if (r<1000){
										 text1.setText("R="+r+" Om "+f);
									 }
									 if ((r>999)&(r<1000000)){
										 r=r/1000;
										 text1.setText("R="+r+" kOm "+f);
									 }
									 if ((r>999999)&(r<1000000000)){
										 r=r/1000000;
										 text1.setText("R="+r+" MOm "+f);
									 }
									 if (r>999999999){
										 r=r/1000000000;
										 text1.setText("R="+r+" GOm "+f);
									 }
									 break;
								 case 6:
									 r=(c1*100)+(c2*10)+c3;
									 r=r*d;
									 if (r<1000){
										 text1.setText("R="+r+" Om "+f+"; "+t+" ppm/C");
									 }
									 if ((r>999)&(r<1000000)){
										 r=r/1000;
										 text1.setText("R="+r+" kOm "+f+"; "+t+" ppm/C");
									 }
									 if ((r>999999)&(r<1000000000)){
										 r=r/1000000;
										 text1.setText("R="+r+" MOm "+f+"; "+t+" ppm/C");
									 }
									 if (r>999999999){
										 r=r/1000000000;
										 text1.setText("R="+r+" GOm "+f+"; "+t+" ppm/C");
									 }
									 break;
								 
								 }
								
							}
						}; 
				       	 	
							b5.setOnClickListener(cb5);	
							
							OnClickListener cb6 = new OnClickListener() {
					        	//@Override	
								public void onClick(View arg0) {
									// TODO Auto-generated method stub
									if(c5<9){
										c5=c5+1;
									}
									if(c5>8){
										c5=1;
									}	
									switch(c5){
									case 1:
										b6.setBackgroundColor(Color.rgb(192, 192, 192));
										b6.invalidate();
										f="10%";
									break;
									case 2:
										b6.setBackgroundColor(Color.rgb(255, 215, 0));
										b6.invalidate();
										f="5%";
									break;
									case 3:
										b6.setBackgroundColor(Color.rgb(165, 42, 42));
										b6.invalidate();
										f="1%";
									break;
									case 4:
										b6.setBackgroundColor(Color.rgb(255, 0, 0));
										b6.invalidate();
										f="2%";
									break;
									case 5:
										b6.setBackgroundColor(Color.rgb(0, 255, 0));
										b6.invalidate();
										f="0,5%";
									break;
									case 6:
										b6.setBackgroundColor(Color.rgb(0, 0, 255));
										b6.invalidate();
										f="0,25%";
									break;
									case 7:
										b6.setBackgroundColor(Color.rgb(238, 130, 238));
										b6.invalidate();
										f="0,1%";
									break;
									case 8:
										b6.setBackgroundColor(Color.rgb(128, 128, 128));
										b6.invalidate();
										f="0,05%";
									break;
																				
									}			
									
									switch(n){
									 case 3:
										 r=(c1*10)+c2;
										 r=r*d;
										 if (r<1000){
											 text1.setText("R="+r+" Om");
										 }
										 if ((r>999)&(r<1000000)){
											 r=r/1000;
											 text1.setText("R="+r+" kOm");
										 }
										 if ((r>999999)&(r<1000000000)){
											 r=r/1000000;
											 text1.setText("R="+r+" MOm");
										 }
										 if (r>999999999){
											 r=r/1000000000;
											 text1.setText("R="+r+" GOm");
										 }
										 break;
									 case 4:
										 r=(c1*10)+c2;
										 r=r*d;
										 if (r<1000){
											 text1.setText("R="+r+" Om "+f);
										 }
										 if ((r>999)&(r<1000000)){
											 r=r/1000;
											 text1.setText("R="+r+" kOm "+f);
										 }
										 if ((r>999999)&(r<1000000000)){
											 r=r/1000000;
											 text1.setText("R="+r+" MOm "+f);
										 }
										 if (r>999999999){
											 r=r/1000000000;
											 text1.setText("R="+r+" GOm "+f);
										 }
										 break;
									 case 5:
										 r=(c1*100)+(c2*10)+c3;
										 r=r*d;
										 if (r<1000){
											 text1.setText("R="+r+" Om "+f);
										 }
										 if ((r>999)&(r<1000000)){
											 r=r/1000;
											 text1.setText("R="+r+" kOm "+f);
										 }
										 if ((r>999999)&(r<1000000000)){
											 r=r/1000000;
											 text1.setText("R="+r+" MOm "+f);
										 }
										 if (r>999999999){
											 r=r/1000000000;
											 text1.setText("R="+r+" GOm "+f);
										 }
										 break;
									 case 6:
										 r=(c1*100)+(c2*10)+c3;
										 r=r*d;
										 if (r<1000){
											 text1.setText("R="+r+" Om "+f+"; "+t+" ppm/C");
										 }
										 if ((r>999)&(r<1000000)){
											 r=r/1000;
											 text1.setText("R="+r+" kOm "+f+"; "+t+" ppm/C");
										 }
										 if ((r>999999)&(r<1000000000)){
											 r=r/1000000;
											 text1.setText("R="+r+" MOm "+f+"; "+t+" ppm/C");
										 }
										 if (r>999999999){
											 r=r/1000000000;
											 text1.setText("R="+r+" GOm "+f+"; "+t+" ppm/C");
										 }
										 break;
									 
									 }
									
								}
							}; 
					       	 	
								b6.setOnClickListener(cb6);
							
								OnClickListener cb7 = new OnClickListener() {
						        	//@Override	
									public void onClick(View arg0) {
										// TODO Auto-generated method stub
										if(c6<8){
											c6=c6+1;
										}
										if(c6>7){
											c6=1;
										}	
										switch(c6){
										case 1:
											b7.setBackgroundColor(Color.rgb(165, 42, 42));
											b7.invalidate();
											t=100;
										break;
										case 2:
											b7.setBackgroundColor(Color.rgb(255, 0, 0));
											b7.invalidate();
											t=50;
										break;
										case 3:
											b7.setBackgroundColor(Color.rgb(255, 165, 0));
											b7.invalidate();
											t=15;
										break;
										case 4:
											b7.setBackgroundColor(Color.rgb(255, 255, 0));
											b7.invalidate();
											t=25;
										break;
										case 5:
											b7.setBackgroundColor(Color.rgb(0, 0, 255));
											b7.invalidate();
											t=10;
										break;
										case 6:
											b7.setBackgroundColor(Color.rgb(238, 130, 238));
											b7.invalidate();
											t=5;
										break;
										case 7:
											b7.setBackgroundColor(Color.rgb(255, 255, 255));
											b7.invalidate();
											t=1;
										break;
																					
										}			
										
										switch(n){
										 case 3:
											 r=(c1*10)+c2;
											 r=r*d;
											 if (r<1000){
												 text1.setText("R="+r+" Om");
											 }
											 if ((r>999)&(r<1000000)){
												 r=r/1000;
												 text1.setText("R="+r+" kOm");
											 }
											 if ((r>999999)&(r<1000000000)){
												 r=r/1000000;
												 text1.setText("R="+r+" MOm");
											 }
											 if (r>999999999){
												 r=r/1000000000;
												 text1.setText("R="+r+" GOm");
											 }
											 break;
										 case 4:
											 r=(c1*10)+c2;
											 r=r*d;
											 if (r<1000){
												 text1.setText("R="+r+" Om "+f);
											 }
											 if ((r>999)&(r<1000000)){
												 r=r/1000;
												 text1.setText("R="+r+" kOm "+f);
											 }
											 if ((r>999999)&(r<1000000000)){
												 r=r/1000000;
												 text1.setText("R="+r+" MOm "+f);
											 }
											 if (r>999999999){
												 r=r/1000000000;
												 text1.setText("R="+r+" GOm "+f);
											 }
											 break;
										 case 5:
											 r=(c1*100)+(c2*10)+c3;
											 r=r*d;
											 if (r<1000){
												 text1.setText("R="+r+" Om "+f);
											 }
											 if ((r>999)&(r<1000000)){
												 r=r/1000;
												 text1.setText("R="+r+" kOm "+f);
											 }
											 if ((r>999999)&(r<1000000000)){
												 r=r/1000000;
												 text1.setText("R="+r+" MOm "+f);
											 }
											 if (r>999999999){
												 r=r/1000000000;
												 text1.setText("R="+r+" GOm "+f);
											 }
											 break;
										 case 6:
											 r=(c1*100)+(c2*10)+c3;
											 r=r*d;
											 if (r<1000){
												 text1.setText("R="+r+" Om "+f+"; "+t+" ppm/C");
											 }
											 if ((r>999)&(r<1000000)){
												 r=r/1000;
												 text1.setText("R="+r+" kOm "+f+"; "+t+" ppm/C");
											 }
											 if ((r>999999)&(r<1000000000)){
												 r=r/1000000;
												 text1.setText("R="+r+" MOm "+f+"; "+t+" ppm/C");
											 }
											 if (r>999999999){
												 r=r/1000000000;
												 text1.setText("R="+r+" GOm "+f+"; "+t+" ppm/C");
											 }
											 break;
										 
										 }
										
									}
								}; 
						       	 	
									b7.setOnClickListener(cb7);
								
    }
}